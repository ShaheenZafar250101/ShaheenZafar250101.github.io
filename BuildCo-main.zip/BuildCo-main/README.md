# BuildCo - A Construction company with Elegance and Class 💯
### Who knows about BuildCo? 

BuildCo is a building and construction company dedicated to excellence, who utilize innovative building construction, maintenance, and renovation skills to change and improve the way Projects are designed, managed, and built.

BuildCo offers services ranging from 

- New building Construction
- Architectural Design 
- Roof Installation
- Commercial and Electrical Installations
- Landscaping & External Works and
- Mechanical and Renewables

**Want to Build with elegance today ?, Contact BuildCo 💯.**

[Check out their Website](https://devdesiign.github.io/BuildCo/)

---

**Just Kidding*

Buildco is yet another imaginary concept created by [Derez - A UIUX Designer](https://twitter.com/iamDeRez1?t=iq9Lmucoy-2BoGiiFQb9Ig&s=08) 💪.

I at the other end was surfing the internet, looking for projects to fuel my range 🔥🔥, then i came across the UI on [Twitter](https://twitter.com/d3vd3511gn)...

I reached out to [Derez](https://twitter.com/iamDeRez1?t=iq9Lmucoy-2BoGiiFQb9Ig&s=08) and he gave me the link to the design. 

*Celebrate Grace* ✨🤍

*Here we are !* [BuilCo - A Construction company with Elegance and Class 💯](https://devdesiign.github.io/BuildCo/)

I'm open to suggestions and reviews.

***Reach out to me via [Twitter](https://twitter.com/d3vd3511gn) and [LinkedIn](https://www.linkedin.com/in/muiz-haruna-321841187/)***

Thanks ✨

🤍 && 🔥

[![Total Time spent](https://wakatime.com/badge/user/fb658d00-4e70-4cd7-8cda-72b8f1ef0325/project/fddcb164-d353-4446-bf84-22e8ede6bee9.svg)](https://wakatime.com/badge/user/fb658d00-4e70-4cd7-8cda-72b8f1ef0325/project/fddcb164-d353-4446-bf84-22e8ede6bee9)
---

## A Demo 👇

https://user-images.githubusercontent.com/57061186/182739165-f889e7d8-06fa-48ee-a09c-ffcdb2012edb.mp4
